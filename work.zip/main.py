import asyncio
import logging
import sys
from aiogram import types
from aiogram.filters.command import CommandStart
from messageHandler import MessageHandler, CourtsNo, JudiProcss, JudiProccDate, MessageTrackNumber, OrderDetails, RespectfulReason, Inn, Debt, Description
from config import dp, bot
from aiogram.fsm.context import FSMContext
handler = MessageHandler()

@dp.message(CommandStart())
async def command_start_handler(message: types.Message) -> None:
    await handler.start(message)

@dp.callback_query()
async def callBack(message: types.CallbackQuery, state: FSMContext):
    await handler.callBack(message, state)

@dp.message(CourtsNo.NO)
async def getCourt(message: types.Message, state: FSMContext):
    await handler.getCourt(message, state)

async def main() -> None:
    await dp.start_polling(bot)


    

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    asyncio.run(main())