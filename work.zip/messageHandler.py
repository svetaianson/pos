from aiogram import types
from config import dp, bot

from database import Database
from aiogram.fsm.context import FSMContext
from states.courts import CourtsNo, JudiProcss, JudiProccDate, MessageTrackNumber, RespectfulReason, OrderDetails, Inn, Debt, Description
import re

class MessageHandler():
    def __init__(self) -> None:
        self.db = Database()

    async def start(self, message: types.Message):
        await self.run(message)
    
    async def run(self, message: types.Message):
        cityBtns = [['Москва', 'moscow'], ['Санкт-Петербург', 'spb'], ['Другой', 'other']]
        markup = self.createInlineButtons(cityBtns)
        await message.answer("Проверьте есть ли на вас судебный приказ и легко отмените его. \n Выберите город:", reply_markup=markup)
    async def callBack(self, message: types.CallbackQuery, state: FSMContext):
        data = message.data
        
        if(data == "other"):
            await message.message.answer("К сожелению на данный момент доступны только 2 города!")
            await self.start(message.message)
        
        elif(data == 'moscow' or data == 'spb'):
            await state.set_data({"city": data})
            await self.checkReceived(message.message)
        
        elif(data == 'received'):
            await state.set_state(CourtsNo.NO.state)
            await message.message.answer("Введите номер судебного участка (или название суда)")
            
        elif(data == 'check'):
            await message.message.answer("Найдите информацию здесь https://mirsud.spb.ru/cases/")
        elif(data == 'checkCourtTrue'):
            await state.set_state(JudiProcss.NO.state)
            await message.message.answer("Введите номер дела (производство №)")
            
        elif(data == 'checkCourtFalse'):
            await state.set_state(CourtsNo.NO.state)
            await message.message.answer("Введите еще раз номер судебного участка или наберите текстом полное наименование судаи ФИО судьи")
            
    async def checkReceived(self, message: types.Message):
        btns = [['Уже получен', 'received'], ['Проверить наличие', 'check']]
        markup = self.createInlineButtons(btns)
        await message.answer("Выберите что хотите сделать:", reply_markup=markup)

    


    async def getCourt(self, message: types.Message, state: FSMContext):
        data = await state.get_data()
        city = data['city']
        text = message.text
        court = self.db.select(f"{city}_courts", "*", f"id = {text}")
        data['court'] = {
            'id': text,
            'name': data[5],
            'phone': data[6],
            'email': data[4]
        }
        await state.set_data(data)
        f"Реквизиты мирового суда:\nСудебный участок №{data[0]}\nМировой судья: {data[5]}\nАдрес: {data[3]}\nТелефон: {data[6]}\nЭлектронный адрес: {data[4]}\nСайт: {data[9]}\nВерно?"
        if not court or len(court) < 1 or court == None:
            return await message.answer("Мировой суд с таким номером не найден!\n\nВведите корректный номер суда:") 
        
        text = self.createMessage(court)
        
        btns = [['Да', 'checkCourtTrue'], ['Нет', 'checkCourtFalse']]
        markup = self.createInlineButtons(btns)
        await message.answer(text, reply_markup=markup)
        await CourtsNo.next()

    def createInlineButtons(self, text: list[list[str]], rowWidth: int = 3):
        buttons = []
        for value in text:
            buttons.append(
                [types.InlineKeyboardButton(text=value[0], callback_data=value[1])]
            )
        markup = types.InlineKeyboardMarkup(inline_keyboard=buttons)
        return markup