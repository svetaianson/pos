from typing  import Union
class DB:
    def select(self, table: str, columns: Union[str, list[str]], identifier: str = None):
        lst=['']*10
        lst[5]="chepuxa"
        lst[6]="89856802868"
        lst[4]="jas@yandex.ru"
        lst[0]=23
        lst[3]="ulitsa pushkina dom kolotushkina"
        lst[9]="www.sud.org"
        return lst