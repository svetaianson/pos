
from os import getenv
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
load_dotenv()
Base = declarative_base()
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String)
    email = Column(String)
    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}', email='{self.email}')>"

class DB:
    def __init__(self):
        username=getenv("DB_USER")
        password=getenv("DB_PASSWORD")
        hostname = getenv("DB_HOST")
        database_name=getenv("DB_NAME")
        port = int(getenv("DB_PORT"))
        connection_string = f'postgresql://{username}:{password}@{hostname}:{port}/{database_name}'
        self.engine = create_engine(connection_string)
        Session = sessionmaker(bind=self.engine)
        self.session = Session()

    def select_user_by_id(self, user_id):
        user = self.session.query(User).filter_by(id=user_id).first()
        return user

    def close(self):
        # Закрываем сессию
        self.session.close()

        
        
        


